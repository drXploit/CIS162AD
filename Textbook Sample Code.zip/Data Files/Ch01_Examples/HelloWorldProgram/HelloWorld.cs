﻿// This is traditionally the first program written.
using System;
using static System.Console;

namespace HelloWorldProgram
{
    class HelloWorld
    {
        static void Main()
        {
            WriteLine("Hello World!");
            ReadKey();
        }
    }
}