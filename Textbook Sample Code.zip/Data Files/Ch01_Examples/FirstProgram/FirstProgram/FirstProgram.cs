﻿using System;
using System.Windows.Forms;

namespace FirstProgram
{
    class FirstProgram
    {
        static void Main(string[] args)
        {
            MessageBox.Show("Welcome to Programming!");
        }
    }
}