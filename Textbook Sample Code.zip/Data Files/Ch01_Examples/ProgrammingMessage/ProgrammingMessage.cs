﻿/*Programmer: [supply your name]
  Date: [supply the current date] 
  Purpose: This class can be used to send messages to the output screen.
*/
using System;
using static System.Console;

namespace ProgrammingMessage
{
    class ProgrammingMessage
    {
        static void Main()
        {
            WriteLine("Programming can be");
            WriteLine("FUN!");
            ReadKey();
        }
    }
}