This is just a HTML document. It was not created in Visual Studio. 
Open the file using a Web browser.